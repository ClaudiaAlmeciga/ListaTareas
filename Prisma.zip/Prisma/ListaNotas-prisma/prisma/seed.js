// prisma/seed.js
import "dotenv/config";
import clientPkg from "@prisma/client";

const { PrismaClient } = clientPkg;
const prisma = new PrismaClient();

async function main() {
  console.log("📌 Iniciando seed...");

  // === INSERT ESTADOS ===
  await prisma.estado.createMany({
    data: [
      { nombre: "Pendiente" },
      { nombre: "En Progreso" },
      { nombre: "Completado" },
      { nombre: "Archivado" },
    ],
    skipDuplicates: true,
  });

  // === INSERT ETIQUETAS ===
  await prisma.etiqueta.createMany({
    data: [
      { nombre: "Trabajo" },
      { nombre: "Personal" },
      { nombre: "Estudios" },
      { nombre: "Salud" },
      { nombre: "Viajes" },
    ],
    skipDuplicates: true,
  });

  // === INSERT USUARIOS ===
  await prisma.usuario.createMany({
    data: [
      {
        nombre: "Juan",
        apellido: "Perez",
        email: "juan@ejemplo.com",
        contrasena: "pass1",
      },
      {
        nombre: "Maria",
        apellido: "Gomez",
        email: "maria@ejemplo.com",
        contrasena: "pass2",
      },
      {
        nombre: "Carlos",
        apellido: "Lopez",
        email: "carlos@ejemplo.com",
        contrasena: "pass3",
      },
      {
        nombre: "Ana",
        apellido: "Martinez",
        email: "ana@ejemplo.com",
        contrasena: "pass4",
      },
      {
        nombre: "Pedro",
        apellido: "Garcia",
        email: "pedro@ejemplo.com",
        contrasena: "pass5",
      },
      {
        nombre: "Laura",
        apellido: "Rodriguez",
        email: "laura@ejemplo.com",
        contrasena: "pass6",
      },
    ],
    skipDuplicates: true,
  });

  // === INSERT NOTAS ===
  await prisma.nota.createMany({
    data: [
      {
        idUsuario: 1,
        titulo: "Comprar pan",
        descripcion: "Ir a la tienda",
        idEstado: 1,
      },
      {
        idUsuario: 1,
        titulo: "Pagar recibo",
        descripcion: "Servicios públicos",
        idEstado: 1,
      },
      {
        idUsuario: 2,
        titulo: "Estudiar JS",
        descripcion: "2 horas mínimo",
        idEstado: 2,
      },
    ],
  });

  // === RELACIONES N:N ===
  await prisma.notaEtiqueta.createMany({
    data: [
      { idNota: 1, idEtiqueta: 1 },
      { idNota: 1, idEtiqueta: 2 },
      { idNota: 2, idEtiqueta: 1 },
    ],
  });

  console.log("🌱 Seed ejecutado correctamente");
}

main()
  .catch((e) => {
    console.error("❌ Error ejecutando seed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
